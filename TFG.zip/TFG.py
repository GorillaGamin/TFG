import pygame
import sys

# Initialize pygame
pygame.init()

# Set up the screen
screen_width, screen_height = 800, 600
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("The Furry Game")

# Define colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GRAY = (150, 150, 150)

# Load images
gorilla_img = pygame.image.load("gorilla.png")
rafael_img = pygame.image.load("rafael.png")

# Scale images to fit the screen
gorilla_img = pygame.transform.scale(gorilla_img, (200, 200))
rafael_img = pygame.transform.scale(rafael_img, (200, 200))

# Define fonts
font = pygame.font.Font(None, 50)

# Cutscene text display function
def display_text(text, y_pos):
    rendered_text = font.render(text, True, WHITE)
    text_rect = rendered_text.get_rect(center=(screen_width // 2, y_pos))
    screen.blit(rendered_text, text_rect)
    pygame.display.update()
    pygame.time.delay(2000)

# Character selection function
def character_selection():
    choices = ["Ryan", "Dylan", "Jason", "Brent"]
    selected = 0

    while True:
        screen.fill(BLACK)
        
        # Display title
        title = font.render("Select your character:", True, WHITE)
        title_rect = title.get_rect(center=(screen_width // 2, 100))
        screen.blit(title, title_rect)

        # Display character choices
        for i, choice in enumerate(choices):
            color = WHITE if i == selected else GRAY
            option = font.render(choice, True, color)
            option_rect = option.get_rect(center=(screen_width // 2, 200 + i * 60))
            screen.blit(option, option_rect)

        pygame.display.update()

        # Handle key events for selection
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP and selected > 0:
                    selected -= 1
                if event.key == pygame.K_DOWN and selected < len(choices) - 1:
                    selected += 1
                if event.key == pygame.K_RETURN:
                    return choices[selected]

# Cutscene function after character selection
def play_cutscene(selected_character):
    screen.fill(BLACK)

    # Character walks to Rafael (just simulate with images)
    screen.blit(gorilla_img, (150, 300))  # Player gorilla
    screen.blit(rafael_img, (500, 300))  # Rafael
    pygame.display.update()

    pygame.time.delay(1000)

    display_text(f"{selected_character} asks to join Rafael's tribe...", 100)
    display_text("Rafael: 'OK, you can join!'", 300)
    pygame.time.delay(1000)

# Main game loop
def main_game():
    screen.fill(BLACK)
    display_text("Welcome to the Gorilla Tribe Camp!", 200)
    pygame.time.delay(2000)

# Main function
def main():
    # Opening credits
    screen.fill(BLACK)
    display_text("Gorilla Gamin' Studios Presents", 200)
    display_text("The Furry Game", 300)

    # Character selection
    selected_character = character_selection()

    # Play cutscene
    play_cutscene(selected_character)

    # Enter main game
    main_game()

    # Game loop
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        # Update game state

        pygame.display.update()

    pygame.quit()

if __name__ == "__main__":
    main()
